<?php

return [
    'name' => 'Connector',
    'module_version' => '2.1',
    'pid' => 9,
];