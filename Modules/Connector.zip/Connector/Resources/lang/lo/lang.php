<?php

return [
    'connector_module' => 'ໂມດູນເຊື່ອມຕໍ່',
    'connector' => 'ຕົວເຊື່ອມຕໍ່',
    'create_client' => 'ສ້າງລູກຄ້າ',
    'client_secret' => 'ຄວາມລັບລູກຄ້າ',
    'clients' => 'ລູກຄ້າ',
    'documentation' => 'ເອກະສານ',
];
